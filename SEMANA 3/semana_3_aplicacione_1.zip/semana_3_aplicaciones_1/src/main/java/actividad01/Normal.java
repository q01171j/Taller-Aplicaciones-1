/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad01;

public class Normal extends Usuario {

    public Normal(String dni, String nombre, String apellido, String contraseña) {
        super(dni, nombre, apellido, contraseña);
    }

    @Override
    public String getRol() {
        return "normal";
    }
}
