/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package actividad01;

import javax.swing.JOptionPane;

/**
 *
 * @author adria
 */
abstract class Figura {

    protected double lado;

    public Figura(double lado) {
        this.lado = lado;
    }

    public abstract double calcularArea();
}

class Cuadrado extends Figura {

    public Cuadrado(double lado) {
        super(lado);
    }

    @Override
    public double calcularArea() {
        return lado * lado;
    }
}

class Triangulo extends Figura {

    public Triangulo(double lado) {
        super(lado);
    }

    @Override
    public double calcularArea() {
        return (lado * lado) / 2;
    }
}

class Rectangulo extends Figura {

    private double alto;

    public Rectangulo(double base, double alto) {
        super(base);
        this.alto = alto;
    }

    @Override
    public double calcularArea() {
        return lado * alto;
    }
}

class Circulo extends Figura {

    public Circulo(double radio) {
        super(radio);
    }

    @Override
    public double calcularArea() {
        return Math.PI * lado * lado;
    }
}

public class GuiMenu extends javax.swing.JFrame {

    /**
     * Creates new form GuiMenu
     */
    public GuiMenu() {
        initComponents();
        this.setLocationRelativeTo(null);
        configuracion();
    }

    private void configuracion() {
        Usuario u = Configuracion.getUsuarioLogueado();

        if (u != null && u.getRol().equals("normal")) {
            tbtnRectangulo.setVisible(false);
            tbtnCirculo.setVisible(false);
        }

        tbtnCuadrado.setSelected(true);
        lblNombre.setText("Bienvenido " + Configuracion.getUsuarioLogueado().getNombreCompleto());

        lblDato2.setVisible(false);
        txtDato2.setVisible(false);

        btnCalcular.setEnabled(false);
        btnNuevo.setEnabled(false);

        lblResultado.setVisible(false);
        txtResultado.setVisible(false);
    }

    private void seleccionarFigura(String figura) {
        switch (figura.toLowerCase()) {
            case "cuadrado":
                lblTitulo.setText("CALCULAR CUADRADO");
                lblDato1.setText("Ingrese el lado:");
                lblDato2.setVisible(false);
                txtDato2.setVisible(false);
                break;
            case "triangulo":
                lblTitulo.setText("CALCULAR TRIANGULO");
                lblDato1.setText("Ingrese la base:");
                lblDato2.setVisible(false);
                txtDato2.setVisible(false);
                break;
            case "circulo":
                lblTitulo.setText("CALCULAR CIRCULO");
                lblDato1.setText("Ingrese el radio:");
                lblDato2.setVisible(false);
                txtDato2.setVisible(false);
                break;
            case "rectangulo":
                lblTitulo.setText("CALCULAR RECTANGULO");
                lblDato1.setText("Ingrese la base:");
                lblDato2.setText("Ingrese la altura:");
                lblDato2.setVisible(true);
                txtDato2.setVisible(true);
                break;
        }

        // Resetear todo
        txtDato1.setText("");
        txtDato2.setText("");
        txtResultado.setText("");

        btnCalcular.setEnabled(false);
        btnNuevo.setEnabled(false);
        txtDato1.setEnabled(true);
        txtDato2.setEnabled(true);
    }

    private void verificarInputs() {
        boolean esRectangulo = tbtnRectangulo.isSelected();

        boolean valido1 = !txtDato1.getText().trim().isEmpty();
        boolean valido2 = !txtDato2.getText().trim().isEmpty();

        if (esRectangulo) {
            btnCalcular.setEnabled(valido1 && valido2);
        } else {
            btnCalcular.setEnabled(valido1);
        }
    }

    private void volver() {
        int respuesta = JOptionPane.showOptionDialog(this, "Estas Seguro de Salir ...", "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Si salgo", "No salgo"}, "No salgo");

        if (respuesta == 0) {
            this.dispose();
            new GuiIngreso().setVisible(true);
        }
    }

    private void soloNumeros(java.awt.event.KeyEvent evt, javax.swing.JTextField txt) {
        char c = evt.getKeyChar();

        if (!Character.isDigit(c) && c != '.' && c != java.awt.event.KeyEvent.VK_BACK_SPACE) {
            evt.consume();
        }

        if (c == '.' && txt.getText().contains(".")) {
            evt.consume();
        }
    }

    private void calcular() {
        double val1 = Double.parseDouble(txtDato1.getText());
        double val2 = txtDato2.isVisible() ? Double.parseDouble(txtDato2.getText()) : 0;

        Figura figura = null;

        if (tbtnCuadrado.isSelected()) {
            figura = new Cuadrado(val1);
        } else if (tbtnTriangulo.isSelected()) {
            figura = new Triangulo(val1);
        } else if (tbtnRectangulo.isSelected()) {
            figura = new Rectangulo(val1, val2);
        } else if (tbtnCirculo.isSelected()) {
            figura = new Circulo(val1);
        }

        if (figura != null) {
            double area = figura.calcularArea();
            txtResultado.setText(String.format("%.2f", area));

            lblResultado.setVisible(true);
            txtResultado.setVisible(true);

            // Expandir panel
            lblResultado.setVisible(true);
            txtResultado.setVisible(true);

            // Desactivar inputs y botones
            txtDato1.setEnabled(false);
            txtDato2.setEnabled(false);
            btnCalcular.setEnabled(false);
            btnNuevo.setEnabled(true);
        }
    }

    private void nuevo() {
        txtDato1.setText("");
        txtDato2.setText("");
        txtResultado.setText("");

        txtDato1.setEnabled(true);
        txtDato2.setEnabled(true);

        btnCalcular.setEnabled(false);
        btnNuevo.setEnabled(false);

        lblResultado.setVisible(false);
        txtResultado.setVisible(false);

        // Reducir panel
        lblResultado.setVisible(false);
        txtResultado.setVisible(false);

        txtDato1.requestFocus();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tbtnGroup = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        btnVolver = new javax.swing.JButton();
        tbtnCuadrado = new javax.swing.JToggleButton();
        tbtnTriangulo = new javax.swing.JToggleButton();
        tbtnRectangulo = new javax.swing.JToggleButton();
        tbtnCirculo = new javax.swing.JToggleButton();
        contenedor = new javax.swing.JPanel();
        lblResultado = new javax.swing.JLabel();
        txtResultado = new javax.swing.JTextField();
        btnCalcular = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        lblTitulo = new javax.swing.JLabel();
        txtDato1 = new javax.swing.JTextField();
        lblDato1 = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblDato2 = new javax.swing.JLabel();
        txtDato2 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu");

        btnVolver.setText("VOLVER INGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        tbtnGroup.add(tbtnCuadrado);
        tbtnCuadrado.setText("CUADRADO");
        tbtnCuadrado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbtnCuadradoActionPerformed(evt);
            }
        });

        tbtnGroup.add(tbtnTriangulo);
        tbtnTriangulo.setText("TRIANGULO");
        tbtnTriangulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbtnTrianguloActionPerformed(evt);
            }
        });

        tbtnGroup.add(tbtnRectangulo);
        tbtnRectangulo.setText("RECTANGULO");
        tbtnRectangulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbtnRectanguloActionPerformed(evt);
            }
        });

        tbtnGroup.add(tbtnCirculo);
        tbtnCirculo.setText("CIRCULO");
        tbtnCirculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbtnCirculoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnVolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tbtnCuadrado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(tbtnRectangulo, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tbtnTriangulo, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tbtnCirculo, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tbtnCuadrado, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tbtnTriangulo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tbtnRectangulo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tbtnCirculo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        contenedor.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblResultado.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        lblResultado.setText("El Area es :");
        contenedor.add(lblResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, -1, 30));

        txtResultado.setEditable(false);
        contenedor.add(txtResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, 190, 30));

        btnCalcular.setText("CALCULAR");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });
        contenedor.add(btnCalcular, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 180, 40));

        btnNuevo.setText("NUEVO");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        contenedor.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, 190, 40));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        lblTitulo.setText("CALCULAR CUADRADO");
        contenedor.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, -1, 30));

        txtDato1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDato1KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDato1KeyTyped(evt);
            }
        });
        contenedor.add(txtDato1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 190, 30));

        lblDato1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        lblDato1.setText("Ingrese el lado:");
        contenedor.add(lblDato1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, 30));

        lblNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNombre.setText("BIENVENIDO USUARIO ADRIANO");
        contenedor.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, 30));

        lblDato2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        lblDato2.setText("Ingrese el lado:");
        contenedor.add(lblDato2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, 30));

        txtDato2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDato2KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDato2KeyTyped(evt);
            }
        });
        contenedor.add(txtDato2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 190, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contenedor, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, 331, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        volver();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tbtnCuadradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbtnCuadradoActionPerformed
        seleccionarFigura(tbtnCuadrado.getText());
    }//GEN-LAST:event_tbtnCuadradoActionPerformed

    private void tbtnTrianguloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbtnTrianguloActionPerformed
        seleccionarFigura(tbtnTriangulo.getText());
    }//GEN-LAST:event_tbtnTrianguloActionPerformed

    private void tbtnRectanguloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbtnRectanguloActionPerformed
        seleccionarFigura(tbtnRectangulo.getText());
    }//GEN-LAST:event_tbtnRectanguloActionPerformed

    private void tbtnCirculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbtnCirculoActionPerformed
        seleccionarFigura(tbtnCirculo.getText());
    }//GEN-LAST:event_tbtnCirculoActionPerformed

    private void txtDato1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDato1KeyReleased
        verificarInputs();
    }//GEN-LAST:event_txtDato1KeyReleased

    private void txtDato2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDato2KeyReleased
        verificarInputs();
    }//GEN-LAST:event_txtDato2KeyReleased

    private void txtDato1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDato1KeyTyped
        soloNumeros(evt, txtDato1);
    }//GEN-LAST:event_txtDato1KeyTyped

    private void txtDato2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDato2KeyTyped
        soloNumeros(evt, txtDato2);
    }//GEN-LAST:event_txtDato2KeyTyped

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        calcular();
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        nuevo();
    }//GEN-LAST:event_btnNuevoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GuiMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GuiMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GuiMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GuiMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GuiMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnVolver;
    private javax.swing.JPanel contenedor;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblDato1;
    private javax.swing.JLabel lblDato2;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JToggleButton tbtnCirculo;
    private javax.swing.JToggleButton tbtnCuadrado;
    private javax.swing.ButtonGroup tbtnGroup;
    private javax.swing.JToggleButton tbtnRectangulo;
    private javax.swing.JToggleButton tbtnTriangulo;
    private javax.swing.JTextField txtDato1;
    private javax.swing.JTextField txtDato2;
    private javax.swing.JTextField txtResultado;
    // End of variables declaration//GEN-END:variables
}
