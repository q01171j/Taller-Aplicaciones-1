/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad01;

public abstract class Usuario {

    protected String dni;
    protected String nombre;
    protected String apellido;
    protected String contraseña;

    public Usuario(String dni, String nombre, String apellido, String contraseña) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.contraseña = contraseña;
    }

    public abstract String getRol();

    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }

    public boolean validarContraseña(String contr) {
        return contraseña.equals(contr);
    }

    public String getDni() {
        return dni;
    }
}
