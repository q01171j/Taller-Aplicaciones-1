/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad01;

import java.util.ArrayList;

public class Configuracion {

    private static ArrayList<Usuario> usuarios = new ArrayList<>();
    private static Usuario usuarioLogueado;

    public static void inicializar() {
        usuarios.add(new Admin("12345678", "Adriano", "Admin", "admin123"));
    }

    public static void registrarUsuario(Usuario u) {
        usuarios.add(u);
    }

    public static Usuario buscarUsuario(String dni) {
        for (Usuario u : usuarios) {
            if (u.getDni().equals(dni)) {
                return u;
            }
        }
        return null;
    }

    public static boolean login(String dni, String pass) {
        Usuario u = buscarUsuario(dni);
        if (u != null && u.validarContraseña(pass)) {
            usuarioLogueado = u;
            return true;
        }
        return false;
    }

    public static Usuario getUsuarioLogueado() {
        return usuarioLogueado;
    }
}
