/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad01;

public class Main {

    public static void main(String[] args) {
        Configuracion.inicializar();

        GuiIngreso form = new GuiIngreso();
        form.setVisible(true);
    }
}
