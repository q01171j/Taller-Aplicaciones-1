/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.util.ArrayList;
import java.util.List;
import modelo.dto.CarnetDTO;

public class CarnetDAO implements ICarnetDAO<CarnetDTO> {

    private static List<CarnetDTO> carnets = new ArrayList<>();
    private static CarnetDTO carnetSeleccionado;

    @Override
    public void crearCarnet(CarnetDTO carnet) {
        carnets.add(carnet);
    }

    @Override
    public List<CarnetDTO> buscarCarnet(String buscar) {
        List<CarnetDTO> resultados = new ArrayList<>();
        for (CarnetDTO c : carnets) {
            if (c.getDni().contains(buscar)
                    || c.getCodigo().contains(buscar)
                    || c.getNombres().toLowerCase().contains(buscar.toLowerCase())
                    || c.getApellidos().toLowerCase().contains(buscar.toLowerCase())) {
                resultados.add(c);
            }
        }
        return resultados;
    }

    @Override
    public void actualizarCarnet(CarnetDTO carnetActualizado) {
        for (CarnetDTO carnet : carnets) {
            if (carnet.getDni().equals(carnetActualizado.getDni())) {
                carnet.actualizarCarnet(
                        carnetActualizado.getApellidos(),
                        carnetActualizado.getNombres(),
                        carnetActualizado.getFacultad(),
                        carnetActualizado.getCarrera(),
                        carnetActualizado.getFechaExpiracion()
                );
                return; // Ya lo actualizamos, podemos salir del método
            }
        }
    }

    @Override
    public void eliminarCarnet(String dni) {
        carnets.removeIf(c -> c.getDni().equals(dni));
    }

    @Override
    public List<CarnetDTO> listarCarnets() {
        return new ArrayList<>(carnets);
    }

    @Override
    public CarnetDTO obtenerCarnet() {
        return carnetSeleccionado;
    }

    @Override
    public void seleccionarCarnet(String dni) {
        for (CarnetDTO carnet : carnets) {
            if (carnet.getDni().equals(dni)) {
                carnetSeleccionado = carnet;
                return;
            }
        }
        carnetSeleccionado = null;
    }

    @Override
    public boolean existeCarnetPorDniOCodigo(String dni, String codigo) {
        for (CarnetDTO carnet : carnets) {
            if (carnet.getDni().equals(dni) || carnet.getCodigo().equals(codigo)) {
                return true;
            }
        }
        return false;
    }

}
