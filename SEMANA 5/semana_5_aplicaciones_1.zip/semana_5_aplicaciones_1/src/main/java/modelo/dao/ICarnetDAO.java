/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo.dao;

import java.util.List;

public interface ICarnetDAO<T> {

    void crearCarnet(T carnet);

    List<T> buscarCarnet(String buscar);

    void actualizarCarnet(T carnet);

    void eliminarCarnet(String dni);

    List<T> listarCarnets();

    T obtenerCarnet();

    void seleccionarCarnet(String dni);

    boolean existeCarnetPorDniOCodigo(String dni, String codigo);
}
