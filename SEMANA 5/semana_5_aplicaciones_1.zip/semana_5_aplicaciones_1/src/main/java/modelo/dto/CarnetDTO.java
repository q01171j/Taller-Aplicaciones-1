/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dto;

import java.util.Date;

public class CarnetDTO {

    private String codigo;
    private String dni;
    private String apellidos;
    private String nombres;
    private String facultad;
    private String carrera;
    private Date fechaExpiracion;
    private byte[] foto;

    public CarnetDTO(String codigo, String dni, String apellidos, String nombres, String facultad, String carrera, Date fechaExpiracion, byte[] foto) {
        this.codigo = codigo;
        this.dni = dni;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.facultad = facultad;
        this.carrera = carrera;
        this.fechaExpiracion = fechaExpiracion;
        this.foto = foto;
    }

    public CarnetDTO(String dni, String apellidos, String nombres, String facultad, String carrera, Date fechaExpiracion) {
        this.dni = dni;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.facultad = facultad;
        this.carrera = carrera;
        this.fechaExpiracion = fechaExpiracion;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDni() {
        return dni;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getNombres() {
        return nombres;
    }

    public String getFacultad() {
        return facultad;
    }

    public String getCarrera() {
        return carrera;
    }

    public Date getFechaExpiracion() {
        return fechaExpiracion;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

    // Método para actualizar todos los datos editables de un carnet
    public void actualizarCarnet(String apellidos, String nombres, String facultad, String carrera, Date fechaExpiracion) {
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.facultad = facultad;
        this.carrera = carrera;
        this.fechaExpiracion = fechaExpiracion;
    }
}
