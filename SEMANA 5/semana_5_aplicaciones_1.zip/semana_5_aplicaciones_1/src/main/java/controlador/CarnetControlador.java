/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.Image;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import modelo.dao.CarnetDAO;
import modelo.dto.CarnetDTO;
import vista.CCarnet;

public class CarnetControlador implements ActionListener {

    private final CCarnet vista;
    private final CarnetDAO dao;
    private final String tipo;
    private byte[] imagenSeleccionada; // <-- para guardar la imagen

    public CarnetControlador(CCarnet vista, String tipo) {
        this.vista = vista;
        this.tipo = tipo;
        this.dao = new CarnetDAO();

        this.vista.btnCrear.addActionListener(this);
        this.vista.btnVolver.addActionListener(this);
        this.vista.cmbFacultad.addActionListener(this);

        // Escuchar click en lblImage
        this.vista.lblImage.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                seleccionarImagen();
            }
        });

        if (tipo.equalsIgnoreCase("actualizar")) {
            cargarDatosCarnet();
        }

        actualizarCarreras();
    }

    private void seleccionarImagen() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Imágenes", "jpg", "jpeg", "png", "gif"));

        int seleccion = fileChooser.showOpenDialog(vista);

        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            try {
                // Mostrar imagen en el JLabel
                ImageIcon icon = new ImageIcon(archivo.getAbsolutePath());
                Image img = icon.getImage().getScaledInstance(vista.lblImage.getWidth(), vista.lblImage.getHeight(), Image.SCALE_SMOOTH);
                vista.lblImage.setIcon(new ImageIcon(img));

                // Guardar imagen como byte[]
                imagenSeleccionada = Files.readAllBytes(archivo.toPath());

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(vista, "Error al cargar la imagen.", "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    private void cargarDatosCarnet() {
        CarnetDTO carnet = dao.obtenerCarnet();
        if (carnet != null) {
            vista.txtDni.setText(carnet.getDni());
            vista.txtCodigo.setText(carnet.getCodigo());
            vista.txtNombre.setText(carnet.getNombres());
            vista.txtApellido.setText(carnet.getApellidos());
            vista.cmbFacultad.setSelectedItem(carnet.getFacultad());
            actualizarCarreras();
            vista.cmbCarrera.setSelectedItem(carnet.getCarrera());
            vista.dcFecha.setDate(carnet.getFechaExpiracion());

            // Bloquear código y DNI para no modificarlos
            vista.txtCodigo.setEditable(false);
            vista.txtDni.setEditable(false);

            // Cargar imagen si existe
            if (carnet.getFoto() != null) {
                ImageIcon icon = new ImageIcon(carnet.getFoto());
                Image img = icon.getImage().getScaledInstance(vista.lblImage.getWidth(), vista.lblImage.getHeight(), Image.SCALE_SMOOTH);
                vista.lblImage.setIcon(new ImageIcon(img));
                imagenSeleccionada = carnet.getFoto(); // para poder actualizar luego
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnVolver) {
            volver();
        } else if (source == vista.btnCrear) {
            if (tipo.equalsIgnoreCase("crear")) {
                crearCarnet();
            } else if (tipo.equalsIgnoreCase("actualizar")) {
                actualizarCarnet();
            }
        } else if (source == vista.cmbFacultad) {
            actualizarCarreras();
        }
    }

    private void volver() {
        vista.dispose();
    }

    private void actualizarCarreras() {
        String facultadSeleccionada = (String) vista.cmbFacultad.getSelectedItem();
        DefaultComboBoxModel<String> modeloCarreras = new DefaultComboBoxModel<>();

        if (facultadSeleccionada == null) {
            return;
        }

        if (facultadSeleccionada.equalsIgnoreCase("Ciencias administrativas y contables")) {
            modeloCarreras.addElement("Administración");
            modeloCarreras.addElement("Administración e Inteligencia de Negocios");
            modeloCarreras.addElement("Administración y Negocios Globales");
            modeloCarreras.addElement("Administración y Gestión del Talento Humano");
            modeloCarreras.addElement("Contabilidad y Finanzas");
        } else if (facultadSeleccionada.equalsIgnoreCase("Derecho y ciencias políticas")) {
            modeloCarreras.addElement("Derecho");
            modeloCarreras.addElement("Educación Inicial");
            modeloCarreras.addElement("Educación Primaria");
        } else if (facultadSeleccionada.equalsIgnoreCase("Ingeniería")) {
            modeloCarreras.addElement("Arquitectura");
            modeloCarreras.addElement("Ingeniería Civil");
            modeloCarreras.addElement("Ingeniería Industrial");
            modeloCarreras.addElement("Ingeniería del Medio Ambiente y Desarrollo");
            modeloCarreras.addElement("Ingeniería de Sistemas y Computación");
        } else if (facultadSeleccionada.equalsIgnoreCase("Ciencias de la Salud")) {
            modeloCarreras.addElement("Enfermería");
            modeloCarreras.addElement("Farmacia y Bioquímica");
            modeloCarreras.addElement("Medicina Veterinaria y Zootecnia");
            modeloCarreras.addElement("Nutrición Humana");
            modeloCarreras.addElement("Obstetricia");
            modeloCarreras.addElement("Odontología");
            modeloCarreras.addElement("Psicología");
            modeloCarreras.addElement("Tecnología Médica");
        } else if (facultadSeleccionada.equalsIgnoreCase("Medicina Humana")) {
            modeloCarreras.addElement("Medicina Humana");
        }

        vista.cmbCarrera.setModel(modeloCarreras);
    }

    private boolean validarCampos() {
        if (vista.txtDni.getText().isEmpty()
                || vista.txtCodigo.getText().isEmpty()
                || vista.txtNombre.getText().isEmpty()
                || vista.txtApellido.getText().isEmpty()
                || vista.cmbFacultad.getSelectedItem() == null
                || vista.cmbCarrera.getSelectedItem() == null
                || vista.dcFecha.getDate() == null
                || imagenSeleccionada == null) { // también validar que suba imagen
            JOptionPane.showMessageDialog(vista, "Debe llenar todos los campos y subir una imagen.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void crearCarnet() {
        if (validarCampos()) {
            String dni = vista.txtDni.getText();
            String codigo = vista.txtCodigo.getText();

            // Validamos que no exista el mismo DNI o Código
            if (dao.existeCarnetPorDniOCodigo(dni, codigo)) {
                JOptionPane.showMessageDialog(vista, "El DNI o Código ya están registrados.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            CarnetDTO nuevo = new CarnetDTO(
                    codigo,
                    dni,
                    vista.txtApellido.getText(),
                    vista.txtNombre.getText(),
                    (String) vista.cmbFacultad.getSelectedItem(),
                    (String) vista.cmbCarrera.getSelectedItem(),
                    vista.dcFecha.getDate(),
                    imagenSeleccionada
            );
            dao.crearCarnet(nuevo);
            JOptionPane.showMessageDialog(vista, "Carnet creado exitosamente.");
            vista.dispose();
        }
    }

    private void actualizarCarnet() {
        if (validarCampos()) {
            CarnetDTO carnetActualizado = dao.obtenerCarnet();
            if (carnetActualizado != null) {
                carnetActualizado.actualizarCarnet(
                        vista.txtApellido.getText(),
                        vista.txtNombre.getText(),
                        (String) vista.cmbFacultad.getSelectedItem(),
                        (String) vista.cmbCarrera.getSelectedItem(),
                        vista.dcFecha.getDate()
                );
                carnetActualizado.setFoto(imagenSeleccionada); // actualizamos también la imagen
                dao.actualizarCarnet(carnetActualizado);
                JOptionPane.showMessageDialog(vista, "Carnet actualizado exitosamente.");
                vista.dispose();
            }
        }
    }
}
