/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.dao.CarnetDAO;
import modelo.dto.CarnetDTO;
import vista.CCarnet;
import vista.CMenu;

public class MenuControlador implements ActionListener, MouseListener, KeyListener {

    private final CMenu vista;
    private final CarnetDAO dao;

    public MenuControlador(CMenu vista) {
        this.vista = vista;
        this.dao = new CarnetDAO();

        this.vista.btnCrear.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnSalir.addActionListener(this);

        this.vista.tblDatos.addMouseListener(this);
        this.vista.txtBuscar.addKeyListener(this);

        // Deshabilitar actualizar y eliminar al inicio
        this.vista.btnActualizar.setEnabled(false);
        this.vista.btnEliminar.setEnabled(false);

        actualizarTabla(dao.listarCarnets());
    }

    private void buscarCarnet() {
        String texto = vista.txtBuscar.getText();
        List<CarnetDTO> resultados = dao.buscarCarnet(texto);
        actualizarTabla(resultados);
    }

    private void actualizarTabla(List<CarnetDTO> lista) {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Código");
        modelo.addColumn("DNI");
        modelo.addColumn("Apellidos");
        modelo.addColumn("Nombres");

        for (CarnetDTO c : lista) {
            modelo.addRow(new Object[]{
                c.getCodigo(), c.getDni(), c.getApellidos(), c.getNombres()
            });
        }

        vista.tblDatos.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnCrear) {
            crear();
        } else if (source == vista.btnActualizar) {
            actualizar();
        } else if (source == vista.btnEliminar) {
            eliminar();
        } else if (source == vista.btnSalir) {
            salir();
        }
    }

    private void crear() {
        CCarnet dialogo = new CCarnet(vista, true, "crear");
        dialogo.setVisible(true);
        actualizarTabla(dao.listarCarnets());
    }

    private void actualizar() {
        if (dao.obtenerCarnet() != null) {
            CCarnet dialogo = new CCarnet(vista, true, "actualizar");
            dialogo.setVisible(true);
            actualizarTabla(dao.listarCarnets());
        } else {
            JOptionPane.showMessageDialog(vista, "Seleccione un carnet primero.");
        }
    }

    private void eliminar() {
        if (dao.obtenerCarnet() != null) {
            int confirm = JOptionPane.showConfirmDialog(vista, "¿Seguro de eliminar este carnet?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dao.eliminarCarnet(dao.obtenerCarnet().getDni());
                actualizarTabla(dao.listarCarnets());
            }
        } else {
            JOptionPane.showMessageDialog(vista, "Seleccione un carnet para eliminar.");
        }
    }

    private void salir() {
        int respuesta = JOptionPane.showOptionDialog(vista, "Estas Seguro de Salir ...", "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Si salgo", "No salgo"}, "No salgo");

        if (respuesta == 0) {
            System.exit(0);
        }

        vista.txtBuscar.requestFocus();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int fila = vista.tblDatos.getSelectedRow();
        if (fila >= 0) {
            String dni = (String) vista.tblDatos.getValueAt(fila, 1); // columna 1 = DNI
            dao.seleccionarCarnet(dni);

            // Habilitar botones actualizar y eliminar
            vista.btnActualizar.setEnabled(true);
            vista.btnEliminar.setEnabled(true);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == vista.txtBuscar) {
            buscarCarnet();
        }
    }
}
