/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.util.ArrayList;
import modelo.dto.UsuarioDTO;

public class UsuarioDAO implements IUsuarioDAO<UsuarioDTO> {

    private static ArrayList<UsuarioDTO> usuarios = new ArrayList<>();
    private static UsuarioDTO usuarioLogueado;

    @Override
    public boolean ingresarUsuario(String dni, String contrasena) {
        UsuarioDTO u = BuscarUsuario(dni);
        if (u != null && u.compararContrasenas(contrasena)) {
            usuarioLogueado = u;
            return true;
        }
        return false;
    }

    @Override
    public UsuarioDTO obtenerUsuarioLogueado() {
        return usuarioLogueado;
    }

    @Override
    public UsuarioDTO BuscarUsuario(String dni) {
        for (UsuarioDTO u : usuarios) {
            if (u.obtenerDni().equals(dni)) {
                return u;
            }
        }
        return null;
    }

    @Override
    public void  crearUsuario(UsuarioDTO usuario) {
        usuarios.add(usuario);
    }

    @Override
    public void inicializar() {
        usuarios.add(new UsuarioDTO("75141615", "adriano", "romero", "admin123", true));
    }
}
