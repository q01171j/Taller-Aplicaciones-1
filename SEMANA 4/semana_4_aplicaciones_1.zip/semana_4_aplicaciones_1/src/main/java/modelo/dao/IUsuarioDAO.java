/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

package modelo.dao;

import java.util.ArrayList;


public interface IUsuarioDAO<T> {
    void inicializar();
    void crearUsuario(T usuario);
    boolean ingresarUsuario(String dni, String contrasena);
    T obtenerUsuarioLogueado();
    T BuscarUsuario(String dni);
}
