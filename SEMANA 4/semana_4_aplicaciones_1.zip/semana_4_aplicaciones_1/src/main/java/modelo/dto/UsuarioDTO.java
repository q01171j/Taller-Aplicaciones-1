/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dto;

public class UsuarioDTO {

    private String dni;
    private String nombre;
    private String apellido;
    private String contraseña;
    private boolean administrador;

    public UsuarioDTO(String dni, String nombre, String apellido, String contraseña, boolean administrador) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.contraseña = contraseña;
        this.administrador = administrador;
    }

    public boolean esAdministrador(){
        return administrador;
    }
    
    public String obtenerDni() {
        return this.dni;
    }

    public boolean compararContrasenas(String contrasenaComparar) {
        return this.contraseña.equals(contrasenaComparar);
    }

    @Override
    public String toString() {
        return nombre + " " + apellido;
    }
}
