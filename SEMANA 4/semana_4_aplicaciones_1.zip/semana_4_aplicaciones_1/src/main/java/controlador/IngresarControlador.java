/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.dao.UsuarioDAO;
import vista.CIngresarVista;
import vista.CMenuVista;
import vista.CRegistrarVista;

public class IngresarControlador implements ActionListener {

    private CIngresarVista vista;
    private UsuarioDAO usuarioDAO;

    public IngresarControlador(CIngresarVista vista) {
        this.vista = vista;
        this.usuarioDAO = new UsuarioDAO();

        this.vista.btnAceptar.addActionListener(this);
        this.vista.btnRegistrar.addActionListener(this);
        this.vista.btnSalir.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object fuente = e.getSource();

        if (fuente == vista.btnAceptar) {
            aceptar();
        } else if (fuente == vista.btnRegistrar) {
            registrar();
        } else if (fuente == vista.btnSalir) {
            salir();
        }
    }

    private void salir() {
        int respuesta = JOptionPane.showOptionDialog(vista, "Estas Seguro de Salir ...", "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Si salgo", "No salgo"}, "No salgo");

        if (respuesta == 0) {
            System.exit(0);
        }

        vista.txtDni.requestFocus();
    }

    private void registrar() {
        CRegistrarVista registro = new CRegistrarVista(vista, true);
        registro.setVisible(true);
    }

    private void aceptar() {
        try {
            String dni = vista.txtDni.getText();
            String contrasena = vista.txtContrasenia.getText();

            if (dni.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Por favor ingresa el DNI", "Campo requerido", JOptionPane.WARNING_MESSAGE);
                vista.txtDni.requestFocus();
                return;
            }

            if (contrasena.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Por favor ingresa la contraseña", "Campo requerido", JOptionPane.WARNING_MESSAGE);
                vista.txtContrasenia.requestFocus();
                return;
            }

            int dniNumero = Integer.parseInt(dni);

            if (dni.length() != 8) {
                JOptionPane.showMessageDialog(vista, "El DNI debe tener exactamente 8 dígitos", "DNI inválido", JOptionPane.WARNING_MESSAGE);
                vista.txtDni.requestFocus();
                return;
            }

            if (usuarioDAO.ingresarUsuario(dni, contrasena)) {
                vista.dispose();
                new CMenuVista().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(vista, "Credenciales incorrectas", "Error de acceso", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "El DNI debe ser numérico", "DNI inválido", JOptionPane.WARNING_MESSAGE);
            vista.txtDni.requestFocus();
        }
    }

}
