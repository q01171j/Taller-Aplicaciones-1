/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import modelo.dto.Circulo;
import modelo.dto.Cuadrado;
import modelo.dto.Figura;
import modelo.dto.Rectangulo;
import modelo.dto.Triangulo;
import vista.CMenuVista;

public class MenuControlador implements ActionListener, KeyListener {

    private CMenuVista vista;

    public MenuControlador(CMenuVista vista) {
        this.vista = vista;

        // Suscripción a eventos
        this.vista.btnVolver.addActionListener(this);
        this.vista.btnCalcular.addActionListener(this);
        this.vista.btnNuevo.addActionListener(this);

        this.vista.tbtnCuadrado.addActionListener(this);
        this.vista.tbtnTriangulo.addActionListener(this);
        this.vista.tbtnRectangulo.addActionListener(this);
        this.vista.tbtnCirculo.addActionListener(this);

        this.vista.txtDato1.addKeyListener(this);
        this.vista.txtDato2.addKeyListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnVolver) {
            volver();
        } else if (source == vista.btnCalcular) {
            calcular();
        } else if (source == vista.btnNuevo) {
            nuevo();
        } else {
            if (source == vista.tbtnCuadrado) {
                seleccionarFigura("cuadrado");
            } else if (source == vista.tbtnTriangulo) {
                seleccionarFigura("triangulo");
            } else if (source == vista.tbtnRectangulo) {
                seleccionarFigura("rectangulo");
            } else if (source == vista.tbtnCirculo) {
                seleccionarFigura("circulo");
            }
        }
    }

    private void seleccionarFigura(String figura) {
        switch (figura.toLowerCase()) {
            case "cuadrado":
                vista.lblTitulo.setText("CALCULAR CUADRADO");
                vista.lblDato1.setText("Ingrese el lado:");
                mostrarCampo2(false);
                break;

            case "triangulo":
                vista.lblTitulo.setText("CALCULAR TRIANGULO");
                vista.lblDato1.setText("Ingrese la base:");
                vista.lblDato2.setText("Ingrese la altura:");
                mostrarCampo2(true);
                break;

            case "rectangulo":
                vista.lblTitulo.setText("CALCULAR RECTANGULO");
                vista.lblDato1.setText("Ingrese la base:");
                vista.lblDato2.setText("Ingrese la altura:");
                mostrarCampo2(true);
                break;

            case "circulo":
                vista.lblTitulo.setText("CALCULAR CIRCULO");
                vista.lblDato1.setText("Ingrese el radio:");
                mostrarCampo2(false);
                break;
        }

        resetCampos();
        verificarInputs();
    }

    private void calcular() {
        try {
            double val1 = Double.parseDouble(vista.txtDato1.getText());
            double val2 = vista.txtDato2.isVisible() ? Double.parseDouble(vista.txtDato2.getText()) : 0;

            Figura figura = null;

            if (vista.tbtnCuadrado.isSelected()) {
                figura = new Cuadrado(val1);
            } else if (vista.tbtnTriangulo.isSelected()) {
                figura = new Triangulo(val1, val2);
            } else if (vista.tbtnRectangulo.isSelected()) {
                figura = new Rectangulo(val1, val2);
            } else if (vista.tbtnCirculo.isSelected()) {
                figura = new Circulo(val1);
            }

            if (figura != null) {
                double area = figura.calcularArea();
                vista.txtResultado.setText(String.format("%.2f", area));
                vista.lblResultado.setVisible(true);
                vista.txtResultado.setVisible(true);

                vista.txtDato1.setEnabled(false);
                vista.txtDato2.setEnabled(false);
                vista.btnCalcular.setEnabled(false);
                vista.btnNuevo.setEnabled(true);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Ingrese valores numéricos válidos.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void nuevo() {
        resetCampos();
        vista.txtDato1.setEnabled(true);
        vista.txtDato2.setEnabled(true);
        vista.btnCalcular.setEnabled(false);
        vista.btnNuevo.setEnabled(false);
        vista.txtDato1.requestFocus();
    }

    private void volver() {
        int respuesta = JOptionPane.showOptionDialog(vista, "¿Estás seguro de volver?", "Salir",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                new Object[]{"Sí", "No"}, "No");

        if (respuesta == 0) {
            vista.dispose();
            // Puedes volver a mostrar la vista de ingreso aquí
        }
    }
    
    private void mostrarCampo2(boolean mostrar) {
        vista.lblDato2.setVisible(mostrar);
        vista.txtDato2.setVisible(mostrar);
    }

    private void resetCampos() {
        vista.txtDato1.setText("");
        vista.txtDato2.setText("");
        vista.txtResultado.setText("");
        vista.lblResultado.setVisible(false);
        vista.txtResultado.setVisible(false);
    }

    private void verificarInputs() {
        boolean valido1 = !vista.txtDato1.getText().trim().isEmpty();
        boolean valido2 = !vista.txtDato2.isVisible() || !vista.txtDato2.getText().trim().isEmpty();
        vista.btnCalcular.setEnabled(valido1 && valido2);
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        JTextField source = (JTextField) e.getSource();

        if ((!Character.isDigit(c) && c != '.' && c != KeyEvent.VK_BACK_SPACE) || (c == '.' && source.getText().contains("."))) {
            e.consume();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        verificarInputs();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
    }

}
