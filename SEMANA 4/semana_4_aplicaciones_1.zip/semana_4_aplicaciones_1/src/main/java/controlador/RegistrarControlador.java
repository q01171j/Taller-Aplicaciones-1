/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.dao.UsuarioDAO;
import modelo.dto.UsuarioDTO;
import vista.CRegistrarVista;

public class RegistrarControlador implements ActionListener {

    private CRegistrarVista vista;
    private UsuarioDAO usuarioDAO;

    public RegistrarControlador(CRegistrarVista vista) {
        this.vista = vista;
        this.usuarioDAO = new UsuarioDAO();

        // Eventos
        this.vista.btnCrear.addActionListener(this);
        this.vista.btnVolver.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object fuente = e.getSource();

        if (fuente == vista.btnCrear) {
            crear();
        } else if (fuente == vista.btnVolver) {
            volver();
        }
    }
    
    private void crear() {
        try {
            String dni = vista.txtDni.getText().trim();
            String nombre = vista.txtNombre.getText().trim();
            String apellido = vista.txtApellido.getText().trim();
            String pass = new String(vista.txtContrasena.getPassword()).trim();
            String repPass = new String(vista.txtRepetirContrasena.getPassword()).trim();

            if (dni.isEmpty() || nombre.isEmpty() || apellido.isEmpty() || pass.isEmpty() || repPass.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Campo vacío", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (dni.length() != 8) {
                JOptionPane.showMessageDialog(vista, "El DNI debe tener exactamente 8 dígitos", "DNI inválido", JOptionPane.WARNING_MESSAGE);
                vista.txtDni.requestFocus();
                return;
            }

            // Validación numérica
            Integer.parseInt(dni); // Lanza NumberFormatException si no es numérico

            if (usuarioDAO.BuscarUsuario(dni) != null) {
                JOptionPane.showMessageDialog(vista, "El DNI ya está registrado", "Usuario existente", JOptionPane.WARNING_MESSAGE);
                vista.txtDni.requestFocus();
                return;
            }

            if (!pass.equals(repPass)) {
                JOptionPane.showMessageDialog(vista, "Las contraseñas no coinciden", "Error de contraseña", JOptionPane.WARNING_MESSAGE);
                return;
            }

            UsuarioDTO nuevo = new UsuarioDTO(dni, nombre, apellido, pass, false);
            usuarioDAO.crearUsuario(nuevo);

            JOptionPane.showMessageDialog(vista, "Usuario registrado correctamente");
            vista.dispose();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "El DNI debe ser numérico", "DNI inválido", JOptionPane.WARNING_MESSAGE);
            vista.txtDni.requestFocus();
        }
    }

    private void volver() {
        vista.dispose();
    }
}
