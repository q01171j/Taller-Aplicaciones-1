/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import modelo.dao.CarnetDAO;
import vista.CMenu;

public class CEjecutar {

    public static void main(String[] args) {
        new CarnetDAO().sincronizarDesdeBaseDeDatos();
        new CMenu().setVisible(true);
    }
}
