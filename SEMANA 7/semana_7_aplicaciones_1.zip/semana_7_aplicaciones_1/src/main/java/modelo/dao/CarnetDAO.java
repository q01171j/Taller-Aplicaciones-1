/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modelo.dto.CarnetDTO;

public class CarnetDAO extends Conn implements ICarnetDAO<CarnetDTO> {

    private static List<CarnetDTO> carnets = new ArrayList<>();
    private static CarnetDTO carnetSeleccionado;

    @Override
    public void crearCarnet(CarnetDTO carnet) {
        String sql = "INSERT INTO Carnets (codigo, dni, apellidos, nombres, facultad, carrera, fecha_expiracion, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = obtenerConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, carnet.getCodigo());
            stmt.setString(2, carnet.getDni());
            stmt.setString(3, carnet.getApellidos());
            stmt.setString(4, carnet.getNombres());
            stmt.setString(5, carnet.getFacultad());
            stmt.setString(6, carnet.getCarrera());
            stmt.setDate(7, new java.sql.Date(carnet.getFechaExpiracion().getTime()));
            stmt.setBytes(8, carnet.getFoto());

            stmt.executeUpdate();

            // Agregamos también al ArrayList si la inserción fue exitosa
            carnets.add(carnet);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actualizarCarnet(CarnetDTO carnetActualizado) {
        String sql = "UPDATE Carnets SET apellidos=?, nombres=?, facultad=?, carrera=?, fecha_expiracion=? WHERE dni=?";
        try (Connection conn = obtenerConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, carnetActualizado.getApellidos());
            stmt.setString(2, carnetActualizado.getNombres());
            stmt.setString(3, carnetActualizado.getFacultad());
            stmt.setString(4, carnetActualizado.getCarrera());
            stmt.setDate(5, new java.sql.Date(carnetActualizado.getFechaExpiracion().getTime()));
            stmt.setString(6, carnetActualizado.getDni());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // También actualizamos en la lista
        for (CarnetDTO carnet : carnets) {
            if (carnet.getDni().equals(carnetActualizado.getDni())) {
                carnet.actualizarCarnet(
                        carnetActualizado.getApellidos(),
                        carnetActualizado.getNombres(),
                        carnetActualizado.getFacultad(),
                        carnetActualizado.getCarrera(),
                        carnetActualizado.getFechaExpiracion()
                );
                return;
            }
        }
    }

    @Override
    public void eliminarCarnet(String dni) {
        String sql = "DELETE FROM Carnets WHERE dni=?";
        try (Connection conn = obtenerConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, dni);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        carnets.removeIf(c -> c.getDni().equals(dni));
    }

    @Override
    public List<CarnetDTO> listarCarnets() {
        return new ArrayList<>(carnets);
    }

    @Override
    public CarnetDTO obtenerCarnet() {
        return carnetSeleccionado;
    }

    @Override
    public void seleccionarCarnet(String dni) {
        for (CarnetDTO carnet : carnets) {
            if (carnet.getDni().equals(dni)) {
                carnetSeleccionado = carnet;
                return;
            }
        }
        carnetSeleccionado = null;
    }

    @Override
    public boolean existeCarnetPorDniOCodigo(String dni, String codigo) {
        for (CarnetDTO carnet : carnets) {
            if (carnet.getDni().equals(dni) || carnet.getCodigo().equals(codigo)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public List<CarnetDTO> buscarCarnet(String buscar) {
        List<CarnetDTO> resultados = new ArrayList<>();
        for (CarnetDTO c : carnets) {
            if (c.getDni().contains(buscar)
                    || c.getCodigo().contains(buscar)
                    || c.getNombres().toLowerCase().contains(buscar.toLowerCase())
                    || c.getApellidos().toLowerCase().contains(buscar.toLowerCase())) {
                resultados.add(c);
            }
        }
        return resultados;
    }

    @Override
    public void sincronizarDesdeBaseDeDatos() {
        carnets.clear();
        String sql = "SELECT * FROM Carnets";
        try (Connection conn = obtenerConexion(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                CarnetDTO carnet = new CarnetDTO(
                        rs.getString("codigo"),
                        rs.getString("dni"),
                        rs.getString("apellidos"),
                        rs.getString("nombres"),
                        rs.getString("facultad"),
                        rs.getString("carrera"),
                        rs.getDate("fecha_expiracion"),
                        rs.getBytes("foto")
                );
                carnets.add(carnet);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
